const express = require("express");
const open = require("open");

const app = express();
const port = process.env.PORT || 3000;

app.use(express.static(__dirname)); // يخلي الموقع يشتغل من مجلد المشروع نفسه

app.listen(port, () => {
  console.log(`السيرفر شغال على http://localhost:${port}`);
  open(`http://localhost:${port}`);
});