document.getElementById("btnPost").onclick = function () {
  document.getElementById("post").classList.add("active");
  document.getElementById("collect").classList.remove("active");
  this.classList.add("active");
  document.getElementById("btnCollect").classList.remove("active");
};

document.getElementById("btnCollect").onclick = function () {
  document.getElementById("collect").classList.add("active");
  document.getElementById("post").classList.remove("active");
  this.classList.add("active");
  document.getElementById("btnPost").classList.remove("active");
};